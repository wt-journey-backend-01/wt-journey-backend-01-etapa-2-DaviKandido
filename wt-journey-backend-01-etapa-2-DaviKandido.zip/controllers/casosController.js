const casosRepository = require("../repositories/casosRepository");
const agentesRepository = require("../repositories/agentesRepository");
const ApiError = require("../utils/errorHandler");


const getCasos = (req, res, next) => {
    try {
        const casos = casosRepository.findAll();

        if(req.query.agente_id){
            const casosFiltrados = casos.filter((caso) => caso.agente_id === req.query.agente_id);
            res.status(200).json(casosFiltrados);
            return;
        }

        if(req.query.status !== 'aberto' && req.query.status !== 'solucionado'){
            return res.status(400).json({
                status: 400,
                message: "Parâmetros inválidos",
                errors: [{status: "O campo 'status' pode ser somente 'aberto' ou 'solucionado' "}]
            });    
        }


        if (req.query.status) {
            const casosFiltrados = casos.filter((caso) => caso.status === req.query.status);
            res.status(200).json(casosFiltrados);
            return;
        }

        res.status(200).json(casos);
    } catch (error) {
        next(new ApiError("Falha ao obter os casos", 500));
    }
};

const getSearch = (req, res, next) => {
  try {
    const casos = casosRepository.findAll();


    if (req.query.q) {
      const casosFiltrados = casos.filter(
        (caso) =>
          caso.titulo.toLowerCase().includes(req.query.q.toLowerCase()) ||
          caso.descricao.toLowerCase().includes(req.query.q.toLowerCase())
      );
      res.status(200).json(casosFiltrados);
      return;
    }

    res.status(200).json(casos);
  } catch (error) {
    next(new ApiError("Falha ao obter os casos", 500));
  }
};

// const getAgenteDoCaso = (req, res, next) => {
//   try {
//     const { caso_id } = req.params;
//     let casos = casosRepository.findAll();

//     if (req.query.agente_id) {
//       casos = casos.filter((caso) => caso.agente_id === req.query.agente_id);
//     }

//     res.status(200).json(casos);
//   } catch (error) {
//     next(new ApiError("Falha ao obter os casos", 500));
//   }
// };

const getCasoById = (req, res, next) => {
  try {
    const caso = casosRepository.findById();
    res.status(200).json(caso);
  } catch (error) {
    next(new ApiError("Falha ao obter o caso", 500));
  }
};

const createCaso = (req, res, next) => {
    try {
        const caso = req.body;
        const casoCreado = casosRepository.create(casoCreado);
        res.status(201).json(caso);
    } catch (error) {
        next(new ApiError("Falha ao criar o caso", 500));
    }
};

const updateCaso = (req, res, next) => {
    try {
        const { id } = req.params;
        const caso = req.body;
        const casoAtualizado = casosRepository.update(id, caso);
        res.status(200).json(casoAtualizado);
    }catch(error){
        next(new ApiError("Falha ao atualizar o caso", 500));
    }
}

const deleteCaso = (req, res, next) => {
    try {
        const deleted = casosRepository.remove(id);

        if(!deleted){
            return next(new ApiError("Caso nao encontrado", 404));
        }

        res.status(204).json();
    }catch(error){
        next(new ApiError("Falha ao deletar o caso", 500))
    }
}

module.exports = {
    getCasos,
    getCasoById,
    getSearch,
    createCaso,
    updateCaso,
    deleteCaso
}