const express = require('express');
const router = express.Router();
const casosController = require('../controllers/casosController');

// Lista todos os casos registrados.
router.get('/', casosController.getCasos);

router.get("/search", casosController.getSearch);

// Retorna os detalhes de um caso específico.
router.get('/:id', casosController.getCasoById);

// Cria um novo caso com os seguintes campos:
router.post('/', casosController.createCaso);

// Atualiza os dados de um caso por completo.
router.put('/:id', casosController.updateCaso);

// Atualiza os dados de um caso parcialmente.
router.patch('/:id', casosController.updateCaso);

// Remove um caso.
router.delete('/:id', casosController.deleteCaso);

module.exports = router;