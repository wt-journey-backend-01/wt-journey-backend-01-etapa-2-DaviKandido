const express = require('express');
const router = express.Router();
const agentesController = require('../controllers/agentesController');

const {agentesPostSchema } = require('../utils/ZodSchemas');


const {validateSchema} = require('../utils/validateSchemas');

// Lista todos os agentes registrados.
router.get('/', agentesController.getAgentes);

// Retorna os detalhes de um caso específico.
router.get('/:id', agentesController.getAgenteById);

// Cria um novo caso com os seguintes campos:
router.post("/", validateSchema(agentesPostSchema), agentesController.createAgente);

// Atualiza os dados de um caso por completo.
router.put('/:id', agentesController.updateAgente);

// Atualiza os dados de um caso parcialmente.
router.patch('/:id', agentesController.updateAgente);

// Remove um caso.
router.delete('/:id', agentesController.deleteAgente);

module.exports = router;