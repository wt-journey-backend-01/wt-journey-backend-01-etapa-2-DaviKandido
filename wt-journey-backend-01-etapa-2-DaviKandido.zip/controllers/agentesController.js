const agentesRepository = require("../repositories/agentesRepository");
const apiError  = require("../utils/errorHandler");



const getAgentes = (req, res, next) => {
    try {
        const agentes = agentesRepository.findAll();

        if(req.query.cargo){
            const agentesFiltrados = agentes.filter((agente) => agente.cargo === req.query.cargo);
            res.status(200).json(agentesFiltrados);
            return;
        }

        if (req.query.sort === "dataDeIncorporacao") {
            agentes.sort((a, b) => new Date(a.dataDeIncorporacao) - new Date(b.dataDeIncorporacao));
        }
        if (req.query.sort === "-dataDeIncorporacao") {
            agentes.sort((a, b) => new Date(b.dataDeIncorporacao) - new Date(a.dataDeIncorporacao));
        }

        res.status(200).json(agentes);
    } catch(error) {
        next(new ApiError("Falha ao obter os agentes", 500));
    }
};

const getAgenteById = (req, res, next) => {
  try {
    const agente = agentesRepository.findById();
    res.status(200).json(agente);
  } catch (error) {
    next(new ApiError("Falha ao obter o agente", 500));
  }
};

const createAgente = (req, res, next) => {
  try {
    const agente = req.body;
    const agenteCreado = agentesRepository.create(agenteCreado);
    res.status(201).json(agente);
  } catch (error) {
    next(new ApiError("Falha ao criar o agente", 500));
  }
};

const updateAgente = (req, res, next) => {
  try {
    const { id } = req.params;
    const agente = req.body;
    const agenteAtualizado = agentesRepository.update(id, agente);
    res.status(200).json(agenteAtualizado);
  } catch (error) {
    next(new ApiError("Falha ao atualizar o agente", 500));
  }
};

const deleteAgente = (req, res, next) => {
  try {
    const deleted = agentesRepository.remove(id);

    if (!deleted) {
      return next(new ApiError("agente nao encontrado", 404));
    }

    res.status(204).json();
  } catch (error) {
    next(new ApiError("Falha ao deletar o agente", 500));
  }
};

module.exports = {
  getAgentes,
  getAgenteById,
  createAgente,
  updateAgente,
  deleteAgente,
};