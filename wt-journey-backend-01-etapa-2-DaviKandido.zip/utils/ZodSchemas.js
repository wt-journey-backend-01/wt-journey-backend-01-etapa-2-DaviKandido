const z = require("zod");

const baseAgenteShema = z.object({
    id: z.never(),
    nome: z.string({
        error: (issue) => {
            issue.input === undefined ? "Campo obrigatório" : "Valor não é um string";
        }
    }).min(1, "O campo 'nome' precisa ter pelo menos 1 caractere"),
    dataDeIncorporacao: z.string().regex(/^\d{4}-\d{2}-\d{2}$/,{ message: "O campo 'dataDeIncorporacao' precisa seguir a formatação 'YYYY-MM-DD'" }).min(1, "O campo 'dataDeIncorporacao' precisa ter pelo menos 1 caractere")
    .refine((dataStr) => {
        const date = new Date()
        return !isNaN(date.getDate() && date.toString().startsWith(dataStr));
    })
    ,
    cargo: z.enum(["Inspetor", "delegado"], {message: "O campo 'cargo' pode ser somente 'Inspetor' ou 'delegado'"})
})


const agentePostSchema = baseAgenteShema.strict();
const agentePutSchema = baseAgenteShema.strict()
const agentePatchSchema = baseAgenteShema.partial();


const casoAgenteSchema = z.object({
  id: z.never(),
  titulo: z.string(),
  descricao: z.string(),
  status: z.enum(["aberto", "solucionado"]),
  status: z.uuidv4()
});

module.exports = {
    agentePostSchema,
    agentePutSchema,
    agentePatchSchema
}